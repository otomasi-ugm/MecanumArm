//#include <DueTimer.h>

/*FYI aja timer due bakalan ganggu si servo
cek aja disini beb, https://github.com/ivanseidel/DueTimer */

void setupInterrupt() {
  //Timer5.getAvailable().attachInterrupt(updateCompass).start(50000); 
  //Timer.getAvailable().attachInterrupt(getPulse).start(10000); 
} 
