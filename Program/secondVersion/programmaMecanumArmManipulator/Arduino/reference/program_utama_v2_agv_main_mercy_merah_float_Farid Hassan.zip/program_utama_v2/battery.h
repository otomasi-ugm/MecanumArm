
void setupBattery(){
  pinMode(A8,INPUT);
  pinMode(A9,INPUT);
}
 
void checkBattery(){
    


}
