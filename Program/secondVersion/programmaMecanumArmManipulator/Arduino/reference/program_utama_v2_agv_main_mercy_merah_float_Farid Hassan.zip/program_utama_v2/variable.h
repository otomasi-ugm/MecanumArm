int gpsMonth,gpsDay,gpsYear,gpsHour,gpsMinute,gpsSecond,targetDegree,headingDegrees,point,headingCorrectionPID,counterBattery,satellite;

int kecepatan,majumundur,kirikanan,errorSteering,errorSteeringMap;

float roll,pitch;

int batteryOne,batteryTwo;

float latitude,longitude;

const int numReadings = 20;
 
//steering things
int mapAngle, desiredAngle, error, pSteering, pwmSteering,startMission;

int readings[numReadings];
int readIndex = 0;
int total = 0;
int average = 0;
int mydata;

int inputPin = A2;

//recive serial
float readLat[100];
float readLon[100];
int totalPoint;

unsigned long timestamp;
