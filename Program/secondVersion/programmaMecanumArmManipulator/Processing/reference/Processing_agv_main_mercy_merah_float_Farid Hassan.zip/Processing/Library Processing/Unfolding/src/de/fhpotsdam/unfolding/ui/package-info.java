/**
 * User Interface (UI) widgets like a compass or a zoom level widget.
 */

package de.fhpotsdam.unfolding.ui;
