/**
 * Handles map as textures for other purposes, such as distortion, fisheye, etc (Unsupported package!).
 */
package de.fhpotsdam.unfolding.texture;
